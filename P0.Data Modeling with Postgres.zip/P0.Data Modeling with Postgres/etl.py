import os
import glob
import psycopg2
import pandas as pd
from sql_queries import *


def process_song_file(cur, filepath):
    """
    This function processes a song file and stores data into songs and artists tables
    Parameters:
        cur (cursor): psycopg2 cursor connection to postgres
        filepath (string): song file path
    """
    # open song file
    song_df = pd.DataFrame(pd.read_json(filepath, lines=True,orient='columns'))

    # insert song record
    # Extract data
    song_data = song_df[['song_id',\
                         'title',\
                         'artist_id',\
                         'year',\
                         'duration']].values[0].tolist()
    cur.execute(song_table_insert, song_data)
    
    # insert artist record
    artist_data = song_df[['artist_id',\
                  'artist_name',\
                  'artist_location',\
                  'artist_latitude',\
                  'artist_longitude']].values[0].tolist()
    cur.execute(artist_table_insert, artist_data)


def process_log_file(cur, filepath):
    """
    Function processes the log files and stores data into time, users and songplay tables
    Parameters:
        cur (cursor): psycopg2 cursor connection to postgres
        filepath (string): log file path
    """
    
    # open log file
    log_df = pd.read_json(filepath, lines=True, orient='columns')

    # filter by NextSong action
    df = log_df[log_df['page'] == 'NextSong']

    # convert timestamp column to datetime
    df['ts'] = pd.to_datetime(df['ts'], unit='ms')
    t = df.copy()
    
    # insert time data records
    # Extract the timestamp, hour, day, week of year, month, year, and weekday from timestamp 
    df["ts"] = pd.to_datetime(df["ts"], unit='ms')
    df["hour"], df["day"], df["week"], df["month"], df["year"], df["weekday"] = \
    df["ts"].apply(lambda x: x.hour), \
    df["ts"].apply(lambda x: x.day), \
    df["ts"].apply(lambda x: x.week), \
    df["ts"].apply(lambda x: x.month), \
    df["ts"].apply(lambda x: x.year), \
    df["ts"].apply(lambda x: x.dayofweek)


    time_data = (df.loc[:,["ts",\
                       "hour",\
                       "day",\
                       "week",\
                       "month",\
                       "year",\
                       "weekday"]].drop_duplicates())

    for i, row in time_data.iterrows():
        cur.execute(time_table_insert, list(row))

   # load user table
    # load user table
    user_data1 = df.get(['userId','firstName','lastName','gender','level'])
    
    # rename_attributes to match the tables already created in sql_queries.py
    user_data1.columns = ['user_id','first_name','last_name','gender','level']

    # data cleanup - remove rows with no user_id
    user_clean = user_data1[user_data1['user_id']!= '']
    
    # data cleanup - remove duplicates
    user_dups_remove = user_clean.drop_duplicates('user_id',keep='first')
    user_df = user_dups_remove

    # insert user records
    for i, row in user_df.iterrows():
        cur.execute(user_table_insert, row)

    # get songid and artistid from song and artist tables
    for index, row in df.iterrows():   
        cur.execute(song_select, (row.song, row.artist, row.length))
        results = cur.fetchone()
    
        if results:
            song_id, artist_id = results
        else:
            song_id, artist_id = None, None

        # insert songplay record
        #create start_time attribute
        start_time = pd.to_datetime(row.ts,unit='ms').strftime('%Y-%m-%d %I:%M:%S')

        # insert songplay record
        songplay_data = [start_time,\
                 row.userId,\
                 row.level,\
                 str(song_id),\
                 str(artist_id),\
                 row.sessionId,\
                 row.location,\
                 row.userAgent]
 
        cur.execute(songplay_table_insert, songplay_data)
    

def process_data(cur, conn, filepath, func):
    """
    Function processes all the data set files and stores the data into the database
    Parameters:
        cur: psycopg2 cursor
        conn: psycopg2 connection object
        filepath (string): path where the data set files are located
        func (function): function to execute (process_song_file or
        process_log_file)
    """
    # get all files matching extension from directory
    all_files = []
    for root, dirs, files in os.walk(filepath):
        files = glob.glob(os.path.join(root,'*.json'))
        for f in files :
            all_files.append(os.path.abspath(f))

    # get total number of files found
    num_files = len(all_files)
    print('{} files found in {}'.format(num_files, filepath))

    # iterate over files and process
    for i, datafile in enumerate(all_files, 1):
        func(cur, datafile)
        conn.commit()
        print('{}/{} files processed.'.format(i, num_files))
        print('All {} files processed OK in {}'.format(num_files, filepath))

def main():
    """
    Perform all the ETL process actions when script is executed.
    Keyword arguments:
    * None
    Output:
    * All input data processed in DB tables.
    """
    conn = psycopg2.connect("host=127.0.0.1 dbname=sparkifydb user=student password=student")
    cur = conn.cursor()

    process_data(cur, conn, filepath='data/song_data', func=process_song_file)
    process_data(cur, conn, filepath='data/log_data', func=process_log_file)

    conn.close()


    if __name__ == "__main__":
        main()